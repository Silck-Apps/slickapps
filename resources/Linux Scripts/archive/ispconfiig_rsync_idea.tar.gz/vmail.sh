dir="/var/vmail"
timeout=5
logfile="vmail.log"
parentdir=$(cd $dir; cd ..; pwd)

logdir="/var/log/ispconfig/rsync/"
logpath=$logdir$logfile
username="root"
servername="ispcfg"
servernumber=(${HOSTNAME: -2})

case $servernumber in
        "01")
          server=$servername"02"
          ;;
        "02")
          server=$servername"01"
          ;;
        *)
         if [ $HOSTNAME == "ispcfg-dev" ]
         then
          server=$servername"01"
         else
          echo "unknown Server"
         fi
         ;;
esac
while [ 0 == 0 ]
do
  rsync -AlXoghrvut $username@$server://$dir $parentdir &>> $logpath
  sleep $timeout
done

