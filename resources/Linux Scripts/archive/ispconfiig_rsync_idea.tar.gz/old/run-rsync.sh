timeout=$(mysql -ubennettw -psambo174 -hlocalhost -Bse "select time from backup_dirs.rsync where folder = '$dir'")
#logfile=$(mysql -ubennettw -psambo174 -hlocalhost -Bse "select logfile from backup_dirs.rsync where folder = '$dir'")
date=$(date)
echo "New rsync on "$date
echo "rysnc client "$server
echo "rsync directory "$dir
read -p "Press [Enter] key to start backup..."
while [ 0 == 0 ]
do
  rsync -avuh $dir $username@$server:$dir
  sleep $timeout
done

