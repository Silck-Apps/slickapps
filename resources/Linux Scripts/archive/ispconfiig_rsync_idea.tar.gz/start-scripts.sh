
OPTIND=1

usage()
{
cat<<EOF
Usage: $0 options

starts rsync scripts for data replication

REQUIRED PARAMETERS:
**** Use one of the following only *****
  -a - start all scripts
  -s - start the given services. valid options are vmail, www or sites-available

OPTIONAL PARAMETERS:
  -h  Shows this message


EOF
}

scriptdir="/srv/resources/scripts/ispconfig/rsync"
scripts="sites-available www"
piddir="/etc/rsync/"

while getopts "as:h" OPTION
do
        case $OPTION in
        h)
         usage
         return
         ;;
	a)
	 restart="all"
	 ;;
	s)
	 restart=$OPTARG	 
	 ;;
        ?)
         usage
         return
         ;;
        esac
done




function checkpid {
  test=$(ps --no-headers -o pid $(cat $pidfile) | tr -d ' ')
read -p ......................................
  if [ -z $test ]
  then
    test="false"
  else
    if [ $test == $1 ]
    then
      test="true"
      read -p ...........................................
    else
      echo "Unexpected test result. Check manually"
    fi
  fi
  
}

function startscript {
  if [ ! -d $piddir ]
  then
    mkdir $piddir
  fi
  pidfile=$piddir/$1".pid"
  if [ ! -a $pidfile ]
  then
    test="false"
  else
    checkpid $(cat $pidfile)
  fi
read -p .......................................
  if [ $test == "false" ]
  then
  . $scriptdir/$1.sh &
  echo $! > $pidfile
  else
    echo "$1 script not started. Process already running"
  fi
} 

case $restart in
  "all")
    echo " start all services"
    for script in $scripts
    do
      startscript $script
    done
    ;;
  "www")
    echo "start www"
    startscript $restart
    ;;
  "sites-available")
    echo "start sites available"
    startscript $restart
    ;;
  *)
    echo "Unkown option $line. valid options are vmail, www and sites-available."
    return
    ;;
esac
