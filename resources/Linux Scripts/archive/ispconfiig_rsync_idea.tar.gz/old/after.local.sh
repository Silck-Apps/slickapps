logdir="/var/log/ispconfig/rsync/"
. /srv/resources/scripts/ispconfig/rsynch/sites-available.sh > $logdir"sites-available.log"
