dirs=$(mysql -ubennettw -psambo174 -hlocalhost -Bse "select folder from backup_dirs.rsync;"
)
logdir="/var/log/ispconfig/rsync/"
username="rsync"
servername="ispcfg"
servernumber=(${HOSTNAME: -2})
case $servernumber in
	"01")
	  server=$servername"02"
	  ;;
	"02")
	  server=$servername"01"
	  ;;
	*)
	 echo "unknown Server"
esac
for dir in $dirs
do
 su rsync -c '/srv/resources/scripts/ispconfig/rsynch/run-rsync.sh > $logdir$logfile.log'
done
