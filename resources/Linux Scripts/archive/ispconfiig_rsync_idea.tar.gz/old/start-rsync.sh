dirs=$(mysql -ubennettw -psambo174 -hlocalhost -Bse "select folder from backup_dirs.rsync;")
logdir="/var/log/ispconfig/rsync/"
username="rsync"
servername="ispcfg"
servernumber=(${HOSTNAME: -2})
case $servernumber in
	"01")
	  server=$servername"02"
	  ;;
	"02")
	  server=$servername"01"
	  ;;
	*)
	 echo "unknown Server"
esac
for dir in $dirs
do
 logfile=$(mysql -ubennettw -psambo174 -hlocalhost -Bse "select logfile from backup_dirs.rsync where folder = '${dir}';")
 logname=$logdir$logfile".log"
 echo "/srv/resources/scripts/ispconfig/rsynch/run-rsync.sh" > $logdir$logfile.log
 echo $logname
 read -p "......."
 echo $dir > /tmp/vars
 echo $server >> /tmp/vars
 echo $username  >> /tmp/vars
 su rsync -c "/srv/resources/scripts/ispconfig/rsynch/run-rsync.sh" > $logname
done
